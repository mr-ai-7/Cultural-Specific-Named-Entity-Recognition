# Cultural-Specific Named Entity Recognition

An IIT Hyderabad natural language processing project that fine-tunes BERT to identify Indian cultural entities in English sentences. For example, in “Gondi is part of Indian tradition,” the model's task is to identify “Gondi” as a language.

[Training notebook](cultural_ner.ipynb) · [Project presentation](presentation.pdf)

## Method and results

The notebook uses concepts and facets from [DIWALI](https://huggingface.co/datasets/nlip/DIWALI) to generate 12,000 template-based sentences with BIO entity tags. It fine-tunes bert-base-uncased for token classification using 9,600 training, 1,200 validation and 1,200 test examples.

The saved run reports an entity-level test F1 of **0.8649** after five epochs. The split is by generated example, so templates and concepts can recur across splits. Performance on independently written text remains unmeasured.

## Run the notebook

Open cultural_ner.ipynb in Jupyter or Google Colab. Install the dependencies in a notebook cell before running the first project cell:

```python
%pip install torch transformers datasets accelerate seqeval scikit-learn numpy matplotlib
```

Run the project cells in order with internet access for the dataset and base model. A GPU is recommended for training. The notebook writes the generated examples to csi_ner_dataset_final.json and exports the trained model and tokenizer to final_model_best/. Random template selection can change the examples and score between runs.
